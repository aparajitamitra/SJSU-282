/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myapp;

/**
 *
 * @author aparajitamitra
 */
public class App {
    public static void main( String[] args )
    {
        System.out.println( "Hey there!" );
            System.out.println("\n The list of numbers is:");
           
        for (int i=0;i<10;i++)
        {
            
            System.out.println("\t" +i);
        
    }
         System.out.println("\n The list of first 10 multiples of 2 is:");
        for (int j=1;j<=10;j++)
        {
            
            System.out.println("\t" +2*j);
        
    }
}
}
